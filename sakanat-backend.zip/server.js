require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");

const User = require("./models/User");

const app = express();
app.use(helmet());
app.use(express.json({ limit: "5mb" }));

/* CORS: يُحدَّد عبر متغير البيئة ALLOWED_ORIGINS (قائمة مفصولة بفواصل)
   مثال: https://donia-labstech.github.io,http://localhost:5500 */
const allowedOrigins = (process.env.ALLOWED_ORIGINS || "*").split(",").map((s) => s.trim());
app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes("*") || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error("غير مسموح بالوصول من هذا المصدر (CORS)"));
  },
}));

app.get("/api/health", (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

app.use("/api/auth", require("./routes/auth"));
app.use("/api/institutions", require("./routes/institutions"));
app.use("/api/cases", require("./routes/cases"));
app.use("/api/eviction-forms", require("./routes/evictionForms"));
app.use("/api/users", require("./routes/users"));
app.use("/api/settings", require("./routes/settings"));
app.use("/api/assistant", require("./routes/assistant"));
app.use("/api/stats", require("./routes/stats"));

app.use((req, res) => res.status(404).json({ error: "المسار غير موجود" }));
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "خطأ غير متوقع في الخادم" });
});

async function ensureSeedAdmin() {
  const count = await User.countDocuments();
  if (count === 0) {
    const seedPassword = process.env.ADMIN_SEED_PASSWORD || "admin123";
    const passwordHash = await bcrypt.hash(seedPassword, 10);
    await User.create({ username: "admin", name: "مدير النظام", role: "admin", passwordHash, mustChangePassword: true });
    console.log(`[seed] تم إنشاء حساب admin الافتراضي بكلمة مرور: ${seedPassword}`);
  }
}

const PORT = process.env.PORT || 4000;
const MONGODB_URI = process.env.MONGODB_URI;

if (!MONGODB_URI) {
  console.error("خطأ: متغير البيئة MONGODB_URI غير مضبوط. راجع ملف .env.example");
  process.exit(1);
}
if (!process.env.JWT_SECRET) {
  console.error("خطأ: متغير البيئة JWT_SECRET غير مضبوط. راجع ملف .env.example");
  process.exit(1);
}

mongoose.connect(MONGODB_URI)
  .then(async () => {
    console.log("[db] تم الاتصال بقاعدة البيانات بنجاح");
    await ensureSeedAdmin();
    app.listen(PORT, () => console.log(`[server] يعمل الخادم على المنفذ ${PORT}`));
  })
  .catch((err) => {
    console.error("[db] فشل الاتصال بقاعدة البيانات:", err.message);
    process.exit(1);
  });
