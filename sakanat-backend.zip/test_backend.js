/* اختبار وظيفي شامل للخادم باستخدام محاكاة mongoose، عبر طلبات HTTP فعلية */
const Module = require("module");
const path = require("path");

const fakeMongoosePath = path.join(__dirname, "test-mocks", "fake-mongoose.js");
const originalLoad = Module._load;
Module._load = function (request, parent, isMain) {
  if (request === "mongoose") return originalLoad.call(this, fakeMongoosePath, parent, isMain);
  return originalLoad.apply(this, arguments);
};

process.env.MONGODB_URI = "mongodb://fake/sakanat";
process.env.JWT_SECRET = "test_secret_key_for_local_testing_only";
process.env.ADMIN_SEED_PASSWORD = "admin123";
process.env.PORT = "4555";
process.env.ALLOWED_ORIGINS = "*";

const BASE = "http://localhost:4555";
let failures = 0;
function check(label, cond, extra) {
  if (cond) console.log("OK  -", label);
  else { failures++; console.log("FAIL -", label, extra !== undefined ? JSON.stringify(extra) : ""); }
}

async function main() {
  require("./server.js");
  await new Promise((r) => setTimeout(r, 400)); // انتظار اتصال "القاعدة" وبدء الاستماع

  // 1) health check
  let r = await fetch(BASE + "/api/health");
  check("health endpoint", r.status === 200);

  // 2) login with wrong password
  r = await fetch(BASE + "/api/auth/login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ username: "admin", password: "wrong" }) });
  check("login rejects wrong password", r.status === 401);

  // 3) login with seeded default admin
  r = await fetch(BASE + "/api/auth/login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ username: "admin", password: "admin123" }) });
  let body = await r.json();
  check("login succeeds with seeded admin", r.status === 200 && !!body.token, body);
  const token = body.token;
  const authHeaders = { "content-type": "application/json", authorization: "Bearer " + token };

  // 4) /me
  r = await fetch(BASE + "/api/auth/me", { headers: authHeaders });
  body = await r.json();
  check("/me returns admin user", r.status === 200 && body.user.username === "admin", body);

  // 5) reject access without token
  r = await fetch(BASE + "/api/institutions");
  check("institutions list rejects unauthenticated", r.status === 401);

  // 6) create institution
  r = await fetch(BASE + "/api/institutions", { method: "POST", headers: authHeaders, body: JSON.stringify({ name: "مدرسة الأمل", type: "ابتدائي", municipality: "الشراقة" }) });
  body = await r.json();
  check("create institution", r.status === 201 && body.name === "مدرسة الأمل", body);
  const instId = body._id;

  // 7) create a case that should trigger RETIRED_OCCUPYING + NO_DECISION_REF flags
  r = await fetch(BASE + "/api/cases", {
    method: "POST", headers: authHeaders,
    body: JSON.stringify({ institutionId: instId, beneficiaryName: "بوعيشة مرزوق", job: "مفتش", occupantStatus: "متقاعد", vacancyStatus: "مشغول" }),
  });
  body = await r.json();
  check("create case", r.status === 201, body);
  check("computed flags include RETIRED_OCCUPYING", (body.flags || []).some((f) => f.code === "RETIRED_OCCUPYING"), body.flags);
  check("computed flags include NO_DECISION_REF", (body.flags || []).some((f) => f.code === "NO_DECISION_REF"), body.flags);
  const caseId = body._id;

  // 8) list cases, list alerts
  r = await fetch(BASE + "/api/cases", { headers: authHeaders });
  body = await r.json();
  check("list cases returns 1", Array.isArray(body) && body.length === 1, body);

  r = await fetch(BASE + "/api/cases/alerts", { headers: authHeaders });
  body = await r.json();
  check("alerts endpoint returns flagged case", Array.isArray(body) && body.length === 1, body);

  // 9) stats
  r = await fetch(BASE + "/api/stats", { headers: authHeaders });
  body = await r.json();
  check("stats endpoint reflects 1 case, 1 flagged, 1 high", body.total === 1 && body.flaggedTotal === 1 && body.high === 1, body);

  // 10) eviction form creation
  r = await fetch(BASE + "/api/eviction-forms", { method: "POST", headers: authHeaders, body: JSON.stringify({ caseId, refNumber: "EVT-TEST-001", dateIssued: "2026-06-24", reason: "تجريبي" }) });
  body = await r.json();
  check("create eviction form", r.status === 201 && body.refNumber === "EVT-TEST-001", body);
  const evictId = body._id;

  // 11) mark eviction executed -> case should become مسترجع
  r = await fetch(BASE + "/api/eviction-forms/" + evictId, { method: "PUT", headers: authHeaders, body: JSON.stringify({ status: "منفذ" }) });
  check("update eviction form status", r.status === 200);
  r = await fetch(BASE + "/api/cases/" + caseId, { headers: authHeaders });
  body = await r.json();
  check("case vacancyStatus became مسترجع after execution", body.vacancyStatus === "مسترجع", body);

  // 12) permission check: create a viewer user, ensure they can't create institutions
  r = await fetch(BASE + "/api/users", { method: "POST", headers: authHeaders, body: JSON.stringify({ username: "viewer1", name: "مستخدم عرض", role: "viewer", password: "1234" }) });
  body = await r.json();
  check("admin creates viewer user", r.status === 201, body);

  r = await fetch(BASE + "/api/auth/login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ username: "viewer1", password: "1234" }) });
  body = await r.json();
  const viewerToken = body.token;
  check("viewer login works", !!viewerToken, body);

  r = await fetch(BASE + "/api/institutions", { method: "POST", headers: { "content-type": "application/json", authorization: "Bearer " + viewerToken }, body: JSON.stringify({ name: "مؤسسة أخرى" }) });
  check("viewer role forbidden from creating institution", r.status === 403);

  r = await fetch(BASE + "/api/institutions", { headers: { authorization: "Bearer " + viewerToken } });
  check("viewer role CAN view institutions list", r.status === 200);

  // 13) settings: aiApiKey must never be returned
  r = await fetch(BASE + "/api/settings", { headers: authHeaders });
  body = await r.json();
  check("settings response never exposes aiApiKey field", body.aiApiKey === undefined, body);
  check("settings response exposes hasAiApiKey boolean instead", typeof body.hasAiApiKey === "boolean", body);

  // 14) bulk import
  r = await fetch(BASE + "/api/cases/bulk-import", {
    method: "POST", headers: authHeaders,
    body: JSON.stringify({ rows: [
      { institutionName: "مدرسة جديدة", beneficiaryName: "فلان الفلاني", job: "مدير مدرسة", vacancyStatus: "مشغول" },
      { institutionName: "مدرسة جديدة", beneficiaryName: "فلانة الفلانية", job: "أستاذة متقاعدة", occupantStatus: "متقاعد", vacancyStatus: "مشغول" },
    ] }),
  });
  body = await r.json();
  check("bulk import creates 2 cases + 1 new institution", body.created === 2 && body.createdInst === 1, body);

  // 15) assistant route: requires auth, and returns a clear error when AI not enabled (default)
  r = await fetch(BASE + "/api/assistant/ask", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ question: "test" }) });
  check("assistant route rejects unauthenticated", r.status === 401);

  r = await fetch(BASE + "/api/assistant/ask", { method: "POST", headers: authHeaders, body: JSON.stringify({ question: "ما وضعية السكنات؟" }) });
  body = await r.json();
  check("assistant route returns clear error when AI disabled by default", r.status === 400 && !!body.error, body);

  console.log(failures === 0 ? "\n=== ALL BACKEND CHECKS PASSED ===" : `\n=== ${failures} FAILURES ===`);
  process.exit(failures === 0 ? 0 : 1);
}

main().catch((e) => { console.error("TEST HARNESS ERROR:", e); process.exit(1); });
