const express = require("express");
const Institution = require("../models/Institution");
const { requireAuth } = require("../middleware/auth");
const { Settings } = require("../models/Settings");
const { computeStats } = require("../utils/stats");

const router = express.Router();
router.use(requireAuth);

router.post("/ask", async (req, res) => {
  const { question } = req.body || {};
  if (!question || !question.trim()) return res.status(400).json({ error: "السؤال مطلوب" });

  const settings = await Settings.findOne({ singleton: "main" });
  const apiKey = process.env.ANTHROPIC_API_KEY || (settings && settings.aiApiKey) || "";
  const aiEnabled = settings ? settings.aiEnabled : false;
  if (!aiEnabled || !apiKey) {
    return res.status(400).json({ error: "ميزة الذكاء الاصطناعي التفاعلي غير مُفعّلة أو لا يوجد مفتاح مضبوط على الخادم" });
  }

  const stats = await computeStats();
  const instCache = {};
  for (const x of stats.flaggedCases.slice(0, 25)) {
    if (!instCache[x.c.institutionId]) {
      const inst = await Institution.findById(x.c.institutionId);
      instCache[x.c.institutionId] = inst ? inst.name : "—";
    }
  }
  const sampleCases = stats.flaggedCases.slice(0, 25).map((x) => ({
    beneficiary: x.c.beneficiaryName || x.c.actualOccupantName,
    institution: instCache[x.c.institutionId],
    flags: x.flags.map((f) => f.label),
  }));

  const context = `إحصائيات عامة: ${JSON.stringify({
    institutions: stats.institutions, total: stats.total, occupied: stats.occupied, vacant: stats.vacant,
    recovered: stats.recovered, notReceived: stats.notReceived, flaggedTotal: stats.flaggedTotal,
    high: stats.high, mid: stats.mid, low: stats.low,
  })}\nأمثلة عن حالات غير نظامية: ${JSON.stringify(sampleCases)}`;

  try {
    const resp = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: (settings && settings.aiModel) || "claude-haiku-4-5-20251001",
        max_tokens: 700,
        system: "أنت مساعد إداري متخصص في تسيير السكنات الوظيفية بمديرية تربية جزائرية. أجب بالعربية الفصحى بشكل عملي ومباشر ومختصر، بالاستناد إلى السياق المُعطى فقط.",
        messages: [{ role: "user", content: `السياق:\n${context}\n\nسؤال المستخدم: ${question}` }],
      }),
    });
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      return res.status(502).json({ error: (err.error && err.error.message) || "تعذّر الاتصال بخدمة الذكاء الاصطناعي" });
    }
    const data = await resp.json();
    const textBlock = (data.content || []).find((b) => b.type === "text");
    res.json({ answer: textBlock ? textBlock.text : "لم يصل رد من الخدمة." });
  } catch (e) {
    res.status(502).json({ error: "تعذّر الاتصال بخدمة الذكاء الاصطناعي: " + e.message });
  }
});

module.exports = router;
