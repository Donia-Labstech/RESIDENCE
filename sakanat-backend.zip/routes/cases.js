const express = require("express");
const Case = require("../models/Case");
const Institution = require("../models/Institution");
const { requireAuth, requirePerm } = require("../middleware/auth");
const { computeFlags, withFlags } = require("../utils/rules");
const { logActivity } = require("../utils/activity");

const router = express.Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const filter = {};
  if (req.query.institutionId) filter.institutionId = req.query.institutionId;
  const list = await Case.find(filter).sort({ createdAt: -1 });
  res.json(list.map(withFlags));
});

router.get("/alerts", async (req, res) => {
  const list = await Case.find();
  const sevRank = (c) => (c.flags.some((f) => f.sev === "high") ? 2 : c.flags.some((f) => f.sev === "mid") ? 1 : 0);
  let flagged = list.map(withFlags).filter((c) => c.flags.length > 0);
  if (req.query.sev) flagged = flagged.filter((c) => c.flags.some((f) => f.sev === req.query.sev));
  flagged.sort((a, b) => sevRank(b) - sevRank(a));
  res.json(flagged);
});

router.get("/:id", async (req, res) => {
  const c = await Case.findById(req.params.id);
  if (!c) return res.status(404).json({ error: "الحالة غير موجودة" });
  res.json(withFlags(c));
});

router.post("/", requirePerm("edit"), async (req, res) => {
  const data = req.body || {};
  if (!data.institutionId) return res.status(400).json({ error: "يجب اختيار مؤسسة" });
  if (!data.beneficiaryName || !data.beneficiaryName.trim()) return res.status(400).json({ error: "اسم المستفيد مطلوب" });
  const c = await Case.create(data);
  await logActivity(req.user.username, "إضافة حالة", c.beneficiaryName);
  res.status(201).json(withFlags(c));
});

router.put("/:id", requirePerm("edit"), async (req, res) => {
  const c = await Case.findById(req.params.id);
  if (!c) return res.status(404).json({ error: "الحالة غير موجودة" });
  Object.assign(c, req.body || {});
  await c.save();
  await logActivity(req.user.username, "تعديل حالة", c.beneficiaryName);
  res.json(withFlags(c));
});

router.delete("/:id", requirePerm("edit"), async (req, res) => {
  const c = await Case.findById(req.params.id);
  if (!c) return res.status(404).json({ error: "الحالة غير موجودة" });
  await c.deleteOne();
  await logActivity(req.user.username, "حذف حالة", c.beneficiaryName);
  res.json({ ok: true });
});

/* استيراد جماعي: يستقبل مصفوفة حالات (تم تجهيزها مسبقاً في المتصفح من ملف إكسل)
   مع أسماء مؤسسات نصية، وينشئ المؤسسات تلقائياً إن لم تكن موجودة */
router.post("/bulk-import", requirePerm("import"), async (req, res) => {
  const { rows, defaultInstitutionId } = req.body || {};
  if (!Array.isArray(rows)) return res.status(400).json({ error: "صيغة غير صحيحة" });
  const instCache = {};
  let created = 0, createdInst = 0, skipped = 0;

  for (const row of rows) {
    const benefName = String(row.beneficiaryName || "").trim();
    const instNameRaw = String(row.institutionName || "").trim();
    if (!benefName && !instNameRaw && !row.apartmentNo && !row.job) { skipped++; continue; }

    let institutionId = defaultInstitutionId;
    if (!institutionId || institutionId === "__auto__") {
      const key = instNameRaw || "(غير محدد)";
      if (!instCache[key]) {
        let existing = await Institution.findOne({ name: key });
        if (!existing) { existing = await Institution.create({ name: key }); createdInst++; }
        instCache[key] = existing._id;
      }
      institutionId = instCache[key];
    }

    const caseData = Object.assign({}, row, { institutionId, beneficiaryName: benefName });
    delete caseData.institutionName;
    await Case.create(caseData);
    created++;
  }

  await logActivity(req.user.username, "استيراد جماعي", `${created} حالة (مؤسسات جديدة: ${createdInst})`);
  res.json({ created, createdInst, skipped });
});

module.exports = router;
