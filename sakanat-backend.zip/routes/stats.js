const express = require("express");
const { requireAuth } = require("../middleware/auth");
const { computeStats } = require("../utils/stats");

const router = express.Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const s = await computeStats();
  res.json({
    institutions: s.institutions, total: s.total, occupied: s.occupied, vacant: s.vacant,
    recovered: s.recovered, notReceived: s.notReceived, flaggedTotal: s.flaggedTotal,
    high: s.high, mid: s.mid, low: s.low,
  });
});

module.exports = router;
