const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const rateLimit = require("express-rate-limit");
const User = require("../models/User");
const { requireAuth, ROLES } = require("../middleware/auth");

const router = express.Router();

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "محاولات كثيرة جداً، يرجى الانتظار قليلاً قبل إعادة المحاولة" },
});

function signToken(user) {
  return jwt.sign({ id: user._id, username: user.username, role: user.role }, process.env.JWT_SECRET, { expiresIn: "12h" });
}

function publicUser(u) {
  return { id: u._id, username: u.username, name: u.name, role: u.role, roleLabel: (ROLES[u.role] || {}).label, mustChangePassword: u.mustChangePassword, createdAt: u.createdAt };
}

router.post("/login", loginLimiter, async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "اسم المستخدم وكلمة المرور مطلوبان" });
  const user = await User.findOne({ username: new RegExp(`^${username.trim()}$`, "i") });
  if (!user) return res.status(401).json({ error: "اسم المستخدم غير صحيح" });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error: "كلمة المرور غير صحيحة" });
  const token = signToken(user);
  res.json({ token, user: publicUser(user) });
});

router.get("/me", requireAuth, async (req, res) => {
  const user = await User.findById(req.user.id);
  if (!user) return res.status(404).json({ error: "المستخدم غير موجود" });
  res.json({ user: publicUser(user) });
});

router.post("/change-password", requireAuth, async (req, res) => {
  const { newPassword } = req.body || {};
  if (!newPassword || newPassword.length < 4) return res.status(400).json({ error: "كلمة المرور قصيرة جداً" });
  const user = await User.findById(req.user.id);
  if (!user) return res.status(404).json({ error: "المستخدم غير موجود" });
  user.passwordHash = await bcrypt.hash(newPassword, 10);
  user.mustChangePassword = false;
  await user.save();
  res.json({ ok: true });
});

module.exports = router;
