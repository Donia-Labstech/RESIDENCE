const express = require("express");
const EvictionForm = require("../models/EvictionForm");
const Case = require("../models/Case");
const { requireAuth, requirePerm } = require("../middleware/auth");
const { logActivity } = require("../utils/activity");

const router = express.Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const list = await EvictionForm.find().sort({ dateIssued: -1 });
  res.json(list);
});

router.post("/", requirePerm("evict"), async (req, res) => {
  const { caseId } = req.body || {};
  if (!caseId) return res.status(400).json({ error: "يجب تحديد الحالة" });
  const c = await Case.findById(caseId);
  if (!c) return res.status(404).json({ error: "الحالة غير موجودة" });
  const form = await EvictionForm.create(req.body);
  await logActivity(req.user.username, "إصدار نموذج إخلاء", form.refNumber);
  res.status(201).json(form);
});

router.put("/:id", requirePerm("evict"), async (req, res) => {
  const form = await EvictionForm.findById(req.params.id);
  if (!form) return res.status(404).json({ error: "النموذج غير موجود" });
  Object.assign(form, req.body || {});
  await form.save();
  if (form.status === "منفذ") {
    const c = await Case.findById(form.caseId);
    if (c) { c.vacancyStatus = "مسترجع"; c.evictionOrder.executed = true; await c.save(); }
  }
  await logActivity(req.user.username, "تحديث نموذج إخلاء", form.refNumber);
  res.json(form);
});

router.delete("/:id", requirePerm("evict"), async (req, res) => {
  const form = await EvictionForm.findById(req.params.id);
  if (!form) return res.status(404).json({ error: "النموذج غير موجود" });
  await form.deleteOne();
  await logActivity(req.user.username, "حذف نموذج إخلاء", form.refNumber);
  res.json({ ok: true });
});

module.exports = router;
