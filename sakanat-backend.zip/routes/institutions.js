const express = require("express");
const Institution = require("../models/Institution");
const Case = require("../models/Case");
const { requireAuth, requirePerm } = require("../middleware/auth");
const { logActivity } = require("../utils/activity");

const router = express.Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const list = await Institution.find().sort({ name: 1 });
  res.json(list);
});

router.post("/", requirePerm("edit"), async (req, res) => {
  const { name, type, municipality, district, totalUnits } = req.body || {};
  if (!name || !name.trim()) return res.status(400).json({ error: "اسم المؤسسة مطلوب" });
  const inst = await Institution.create({ name: name.trim(), type, municipality, district, totalUnits: Number(totalUnits) || 0 });
  await logActivity(req.user.username, "إضافة مؤسسة", inst.name);
  res.status(201).json(inst);
});

router.put("/:id", requirePerm("edit"), async (req, res) => {
  const { name, type, municipality, district, totalUnits } = req.body || {};
  const inst = await Institution.findById(req.params.id);
  if (!inst) return res.status(404).json({ error: "المؤسسة غير موجودة" });
  if (name !== undefined) inst.name = name.trim();
  if (type !== undefined) inst.type = type;
  if (municipality !== undefined) inst.municipality = municipality;
  if (district !== undefined) inst.district = district;
  if (totalUnits !== undefined) inst.totalUnits = Number(totalUnits) || 0;
  await inst.save();
  await logActivity(req.user.username, "تعديل مؤسسة", inst.name);
  res.json(inst);
});

router.delete("/:id", requirePerm("edit"), async (req, res) => {
  const inst = await Institution.findById(req.params.id);
  if (!inst) return res.status(404).json({ error: "المؤسسة غير موجودة" });
  const deletedCases = await Case.deleteMany({ institutionId: inst._id });
  await inst.deleteOne();
  await logActivity(req.user.username, "حذف مؤسسة", `${inst.name} (مع ${deletedCases.deletedCount} حالة)`);
  res.json({ ok: true, deletedCases: deletedCases.deletedCount });
});

module.exports = router;
