const express = require("express");
const { Settings, ActivityLog } = require("../models/Settings");
const { requireAuth, requirePerm } = require("../middleware/auth");
const { logActivity } = require("../utils/activity");

const router = express.Router();
router.use(requireAuth);

async function getOrCreateSettings() {
  let s = await Settings.findOne({ singleton: "main" });
  if (!s) s = await Settings.create({ singleton: "main" });
  return s;
}

router.get("/", async (req, res) => {
  const s = await getOrCreateSettings();
  const obj = s.toObject();
  obj.hasAiApiKey = !!(process.env.ANTHROPIC_API_KEY || obj.aiApiKey);
  delete obj.aiApiKey; // لا يُعاد مفتاح الذكاء الاصطناعي أبداً إلى الواجهة لأي سبب
  res.json(obj);
});

router.put("/", requirePerm("edit"), async (req, res) => {
  const s = await getOrCreateSettings();
  const body = req.body || {};
  if (body.org) Object.assign(s.org, body.org);
  if (body.theme !== undefined) s.theme = body.theme;
  if (body.hideCopyright !== undefined) s.hideCopyright = body.hideCopyright;
  if (body.evictionGraceDays !== undefined) s.evictionGraceDays = Number(body.evictionGraceDays) || 30;
  if (body.aiEnabled !== undefined) s.aiEnabled = !!body.aiEnabled;
  if (body.aiModel !== undefined) s.aiModel = body.aiModel;
  if (body.aiApiKey !== undefined && body.aiApiKey !== "") s.aiApiKey = body.aiApiKey; // يُحفظ لكن لا يُعاد إطلاقاً
  await s.save();
  await logActivity(req.user.username, "تحديث الإعدادات", "");
  const obj = s.toObject();
  obj.hasAiApiKey = !!(process.env.ANTHROPIC_API_KEY || obj.aiApiKey);
  delete obj.aiApiKey;
  res.json(obj);
});

router.get("/activity-log", async (req, res) => {
  if (req.user.role !== "admin") return res.status(403).json({ error: "هذا الإجراء مخصص لمدير النظام فقط" });
  const logs = await ActivityLog.find().sort({ at: -1 }).limit(300);
  res.json(logs);
});

module.exports = router;
