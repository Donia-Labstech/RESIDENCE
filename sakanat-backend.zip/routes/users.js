const express = require("express");
const bcrypt = require("bcryptjs");
const User = require("../models/User");
const { requireAuth, ROLES } = require("../middleware/auth");
const { logActivity } = require("../utils/activity");

const router = express.Router();
router.use(requireAuth);

function requireAdmin(req, res, next) {
  if (req.user.role !== "admin") return res.status(403).json({ error: "هذا الإجراء مخصص لمدير النظام فقط" });
  next();
}

function publicUser(u) {
  return { id: u._id, username: u.username, name: u.name, role: u.role, roleLabel: (ROLES[u.role] || {}).label, mustChangePassword: u.mustChangePassword, createdAt: u.createdAt };
}

router.get("/", requireAdmin, async (req, res) => {
  const list = await User.find().sort({ createdAt: 1 });
  res.json(list.map(publicUser));
});

router.post("/", requireAdmin, async (req, res) => {
  const { username, name, role, password } = req.body || {};
  if (!username || !username.trim()) return res.status(400).json({ error: "اسم المستخدم مطلوب" });
  if (!ROLES[role]) return res.status(400).json({ error: "صلاحية غير معروفة" });
  const exists = await User.findOne({ username: new RegExp(`^${username.trim()}$`, "i") });
  if (exists) return res.status(409).json({ error: "اسم المستخدم موجود مسبقاً" });
  const passwordHash = await bcrypt.hash(password || "1234", 10);
  const user = await User.create({ username: username.trim(), name, role, passwordHash, mustChangePassword: true });
  await logActivity(req.user.username, "إضافة مستخدم", user.username);
  res.status(201).json(publicUser(user));
});

router.put("/:id", requireAdmin, async (req, res) => {
  const { name, role } = req.body || {};
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ error: "المستخدم غير موجود" });
  if (name !== undefined) user.name = name;
  if (role !== undefined) { if (!ROLES[role]) return res.status(400).json({ error: "صلاحية غير معروفة" }); user.role = role; }
  await user.save();
  await logActivity(req.user.username, "تعديل مستخدم", user.username);
  res.json(publicUser(user));
});

router.post("/:id/reset-password", requireAdmin, async (req, res) => {
  const { newPassword } = req.body || {};
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ error: "المستخدم غير موجود" });
  user.passwordHash = await bcrypt.hash(newPassword || "1234", 10);
  user.mustChangePassword = true;
  await user.save();
  await logActivity(req.user.username, "إعادة ضبط كلمة مرور", user.username);
  res.json({ ok: true });
});

router.delete("/:id", requireAdmin, async (req, res) => {
  if (String(req.params.id) === String(req.user.id)) return res.status(400).json({ error: "لا يمكنك حذف حسابك الخاص" });
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ error: "المستخدم غير موجود" });
  await user.deleteOne();
  await logActivity(req.user.username, "حذف مستخدم", user.username);
  res.json({ ok: true });
});

module.exports = router;
