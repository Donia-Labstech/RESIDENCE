# دليل نشر الخادم (Backend) — نظام تسيير السكنات الوظيفية

هذا الدليل يشرح خطوة بخطوة كيفية نشر الخادم مجاناً على **Render**، مع قاعدة بيانات **MongoDB Atlas** (مجانية أيضاً)، بحيث يتصل به تطبيق الواجهة المرفوع على GitHub Pages.

---

## الخطوة 1: إنشاء قاعدة بيانات مجانية (MongoDB Atlas)

1. اذهب إلى https://www.mongodb.com/cloud/atlas/register وأنشئ حساباً مجانياً.
2. أنشئ مشروعاً جديداً (Project)، ثم أنشئ Cluster من نوع **M0 (مجاني للأبد)**.
3. من قائمة **Database Access**: أنشئ مستخدم قاعدة بيانات جديد (اسم مستخدم + كلمة مرور قوية) — احتفظ بهما.
4. من قائمة **Network Access**: أضف عنوان IP وفعّل **Allow Access from Anywhere (0.0.0.0/0)** — ضروري لأن Render لا يوفر عنوان IP ثابتاً في الخطة المجانية.
5. من **Database > Connect > Drivers**: انسخ رابط الاتصال (Connection String)، شكله:
   ```
   mongodb+srv://USERNAME:PASSWORD@CLUSTER.mongodb.net/?retryWrites=true&w=majority
   ```
   عدّله بإضافة اسم قاعدة البيانات بعد الشرطة الأخيرة، مثلاً:
   ```
   mongodb+srv://USERNAME:PASSWORD@CLUSTER.mongodb.net/sakanat?retryWrites=true&w=majority
   ```
   استبدل `USERNAME` و `PASSWORD` بما أنشأته في الخطوة 3.

## الخطوة 2: رفع كود الخادم على GitHub

1. أنشئ مستودعاً (Repository) جديداً على GitHub، مثلاً `RESIDENCE-backend` (أو أضف هذا المجلد كمجلد فرعي `backend/` داخل مستودع `RESIDENCE` الحالي — Render يدعم الحالتين).
2. ارفع جميع ملفات هذا المجلد (server.js, package.json, models/, routes/, middleware/, utils/...) إليه.
   **لا ترفع** ملف `.env` أبداً (لن يُرفع تلقائياً بسبب `.gitignore`)، ولا مجلد `node_modules`.

## الخطوة 3: إنشاء الخادم على Render

1. اذهب إلى https://render.com وأنشئ حساباً مجانياً (يمكن الدخول مباشرة بحساب GitHub).
2. اضغط **New +** ثم **Web Service**.
3. اختر مستودع GitHub الذي رفعت إليه الكود.
4. إن كان الكود في مجلد فرعي (مثل `backend/` داخل مستودع RESIDENCE)، حدد ذلك في خانة **Root Directory**.
5. اضبط:
   - **Build Command**: `npm install`
   - **Start Command**: `node server.js`
   - **Instance Type**: `Free`
6. في قسم **Environment Variables** أضف:

   | المفتاح | القيمة |
   |---|---|
   | `MONGODB_URI` | رابط الاتصال من الخطوة 1 |
   | `JWT_SECRET` | نص عشوائي طويل وسرّي (اضغط "Generate" إن توفر، أو اكتب نصاً عشوائياً لا يقل عن 32 حرفاً) |
   | `ALLOWED_ORIGINS` | `https://donia-labstech.github.io` (عنوان موقعكم على GitHub Pages) |
   | `ADMIN_SEED_PASSWORD` | كلمة مرور حساب admin الأولى، مثلاً `admin123` |
   | `ANTHROPIC_API_KEY` | (اختياري) مفتاح الذكاء الاصطناعي إن رغبتم بتفعيله — يبقى على الخادم فقط ولا يصل للمتصفح أبداً |

7. اضغط **Create Web Service**. سينشر Render الكود تلقائياً ويعطيكم رابطاً شكله:
   ```
   https://sakanat-backend.onrender.com
   ```

## الخطوة 4: التأكد من عمل الخادم

افتحوا في المتصفح:
```
https://sakanat-backend.onrender.com/api/health
```
إن ظهرت لكم رسالة مثل `{"ok":true,"time":"..."}` فالخادم يعمل بنجاح. ✅

## ⚠️ ملاحظة مهمة عن الخطة المجانية على Render

الخطة المجانية تُسكِت (Sleep) الخادم تلقائياً بعد **15 دقيقة من عدم الاستخدام**، وأول طلب بعد فترة الخمول يستغرق من **30 إلى 60 ثانية** لإعادة تشغيله (Cold Start). هذا أمر طبيعي في الخطط المجانية ولا يدل على عطل — فقط أول استخدام بعد فترة توقف سيكون أبطأ من المعتاد.

## الخطوة التالية

بعد إكمال هذه الخطوات، أرسلوا لي رابط الخادم (`https://sakanat-backend.onrender.com`) لأقوم بربط تطبيق الواجهة (المرفوع على GitHub Pages) به مباشرة، بحيث تُحفظ كل البيانات (المؤسسات، الحالات، المستخدمين) في قاعدة البيانات الحقيقية بدل التخزين المحلي في المتصفح.

---

## للمطورين: تشغيل واختبار الخادم محلياً

```bash
npm install
cp .env.example .env   # ثم عدّل القيم داخل .env
npm start
```

ملف `test_backend.js` يحتوي اختباراً وظيفياً شاملاً (23 فحصاً) يعمل بمحاكاة داخلية لقاعدة البيانات دون الحاجة لـ MongoDB حقيقية — مفيد للتحقق السريع من سلامة الكود بعد أي تعديل:
```bash
npm test
```
