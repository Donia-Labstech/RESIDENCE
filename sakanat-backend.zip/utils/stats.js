const Case = require("../models/Case");
const Institution = require("../models/Institution");
const { computeFlags } = require("./rules");

async function computeStats() {
  const cases = await Case.find();
  const institutionsCount = await Institution.countDocuments();
  const total = cases.length;
  const occupied = cases.filter((c) => c.vacancyStatus === "مشغول").length;
  const vacant = cases.filter((c) => c.vacancyStatus === "شاغر").length;
  const recovered = cases.filter((c) => c.vacancyStatus === "مسترجع").length;
  const notReceived = cases.filter((c) => c.vacancyStatus === "غير_مستلم").length;
  const flaggedCases = cases.map((c) => ({ c, flags: computeFlags(c) })).filter((x) => x.flags.length > 0);
  const high = flaggedCases.filter((x) => x.flags.some((f) => f.sev === "high")).length;
  const mid = flaggedCases.filter((x) => !x.flags.some((f) => f.sev === "high") && x.flags.some((f) => f.sev === "mid")).length;
  const low = flaggedCases.length - high - mid;
  return {
    institutions: institutionsCount, total, occupied, vacant, recovered, notReceived,
    flaggedTotal: flaggedCases.length, high, mid, low, flaggedCases,
  };
}

module.exports = { computeStats };
