/* محرك الكشف عن الحالات غير القانونية - نسخة الخادم (مطابقة لمحرك الواجهة) */
function fmtDate(d) {
  if (!d) return "—";
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return String(d);
  return dt.toLocaleDateString("ar-DZ", { year: "numeric", month: "2-digit", day: "2-digit" });
}

const RULES = [
  {
    code: "RETIRED_OCCUPYING", sev: "high",
    test: (c) => c.occupantStatus === "متقاعد" && c.vacancyStatus === "مشغول" && !(c.evictionOrder && c.evictionOrder.executed),
    label: "موظف متقاعد لا يزال يشغل السكن الوظيفي",
    detail: (c) => `المستفيد "${c.beneficiaryName || "—"}" في وضعية تقاعد وما يزال يشغل السكن دون إخلاء.`,
  },
  {
    code: "DECEASED_OCCUPIED", sev: "high",
    test: (c) => c.occupantStatus === "متوفى" && c.vacancyStatus === "مشغول",
    label: "السكن مشغول بعد وفاة المستفيد الأصلي",
    detail: (c) => `المستفيد الأصلي "${c.beneficiaryName || "—"}" متوفٍ والسكن لا يزال مشغولاً` + (c.actualOccupantName ? ` من طرف: ${c.actualOccupantName}` : "") + ".",
  },
  {
    code: "OCCUPIED_BY_OTHER", sev: "high",
    test: (c) => !!c.actualOccupantName && c.actualOccupantName.trim() !== "" && c.actualOccupantName.trim() !== (c.beneficiaryName || "").trim() && c.occupantStatus !== "متوفى",
    label: "السكن يشغله شخص غير المستفيد الرسمي",
    detail: (c) => `السكن مخصص لـ "${c.beneficiaryName || "—"}" لكنه مشغول فعلياً من طرف "${c.actualOccupantName}"` + (c.actualOccupantRelation ? ` (${c.actualOccupantRelation})` : "") + ".",
  },
  {
    code: "NO_DECISION_REF", sev: "mid",
    test: (c) => c.vacancyStatus === "مشغول" && (!c.decisionRef || !String(c.decisionRef.number || "").trim() || c.decisionRef.number === "/"),
    label: "إشغال بدون مرجع قرار استفادة",
    detail: () => `لا يوجد مرجع قرار استفادة مسجل لهذا السكن المشغول، وهو سند قانوني ضروري لإثبات شرعية الإشغال.`,
  },
  {
    code: "PENDING_EVICTION", sev: "mid",
    test: (c) => c.evictionOrder && c.evictionOrder.issued && !c.evictionOrder.executed,
    label: "أمر إخلاء صادر دون تنفيذ أو متابعة",
    detail: (c) => `صدر أمر/قرار إخلاء بتاريخ ${fmtDate(c.evictionOrder.date)} ولم يُنفذ إلى الآن.`,
  },
  {
    code: "OUTSIDE_SECTOR_UNVERIFIED", sev: "mid",
    test: (c) => c.benefitType === "خارج القطاع" && (!c.decisionRef || !String(c.decisionRef.number || "").trim()),
    label: "شاغل من خارج قطاع التربية الوطنية بدون سند",
    detail: (c) => `الشاغل "${c.beneficiaryName || c.actualOccupantName || "—"}" لا ينتمي لقطاع التربية الوطنية ولا يوجد مرجع قانوني موثق لإشغاله.`,
  },
  {
    code: "NOT_MOVED_IN", sev: "mid",
    test: (c) => !!c.notMovedIn,
    label: "المعني لم يلتحق بالسكن الوظيفي المخصص له",
    detail: (c) => `المستفيد معيّن بسكن وظيفي إلزامي بهذه المؤسسة ولم يلتحق به` + (c.actualResidenceNote ? `، ويُذكر أنه يقطن: ${c.actualResidenceNote}` : "") + ".",
  },
  {
    code: "UNUSED_BY_BENEFICIARY", sev: "low",
    test: (c) => !!c.unusedByBeneficiary,
    label: "السكن غير مستغل فعلياً من طرف المستفيد",
    detail: (c) => `السكن مسجل كمشغول رسمياً لكنه غير مستغل فعلياً من طرف المستفيد "${c.beneficiaryName || "—"}".`,
  },
  {
    code: "LONG_VACANT", sev: "low",
    test: (c) => c.vacancyStatus === "شاغر",
    label: "سكن شاغر يتطلب إعادة توزيع",
    detail: () => `السكن شاغر حالياً ضمن مؤسسة بها طلبات سكن قائمة، يفضل تسريع إعادة التوزيع.`,
  },
];

function computeFlags(c) {
  const out = [];
  RULES.forEach((r) => {
    try {
      if (r.test(c)) out.push({ code: r.code, sev: r.sev, label: r.label, detail: r.detail(c) });
    } catch (e) { /* تجاهل */ }
  });
  (c.manualFlags || []).forEach((mf) => out.push({ code: "MANUAL", sev: mf.sev || "mid", label: mf.label, detail: mf.detail || "" }));
  return out;
}

function withFlags(caseDoc) {
  const obj = typeof caseDoc.toObject === "function" ? caseDoc.toObject() : caseDoc;
  obj.flags = computeFlags(obj);
  return obj;
}

module.exports = { computeFlags, withFlags, RULES };
