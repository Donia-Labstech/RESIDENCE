const { ActivityLog } = require("../models/Settings");

async function logActivity(user, action, detail) {
  try {
    await ActivityLog.create({ user, action, detail });
    const count = await ActivityLog.countDocuments();
    if (count > 1000) {
      const toRemove = await ActivityLog.find().sort({ at: 1 }).limit(count - 1000).select("_id");
      await ActivityLog.deleteMany({ _id: { $in: toRemove.map((d) => d._id) } });
    }
  } catch (e) { /* لا نُفشل الطلب الأساسي بسبب خطأ في السجل */ }
}

module.exports = { logActivity };
