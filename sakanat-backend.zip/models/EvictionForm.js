const mongoose = require("mongoose");

const evictionFormSchema = new mongoose.Schema({
  caseId: { type: mongoose.Schema.Types.ObjectId, ref: "Case", required: true },
  refNumber: { type: String, default: "" },
  dateIssued: { type: String, default: "" },
  graceDays: { type: Number, default: 30 },
  issuer: { type: String, default: "مدير التربية" },
  reason: { type: String, default: "" },
  notes: { type: String, default: "" },
  status: { type: String, enum: ["محرر", "مسلم", "منفذ"], default: "محرر" },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("EvictionForm", evictionFormSchema);
