const mongoose = require("mongoose");

const institutionSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  type: { type: String, default: "ابتدائي" },
  municipality: { type: String, default: "" },
  district: { type: String, default: "" },
  totalUnits: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Institution", institutionSchema);
