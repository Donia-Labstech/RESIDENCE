const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true, trim: true },
  name: { type: String, default: "" },
  role: { type: String, enum: ["admin", "finance", "inspector", "viewer"], default: "viewer" },
  passwordHash: { type: String, required: true },
  mustChangePassword: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("User", userSchema);
