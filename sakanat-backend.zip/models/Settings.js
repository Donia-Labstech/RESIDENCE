const mongoose = require("mongoose");

const settingsSchema = new mongoose.Schema({
  singleton: { type: String, default: "main", unique: true },
  org: {
    country: { type: String, default: "الجمهورية الجزائرية الديمقراطية الشعبية" },
    ministry: { type: String, default: "وزارة التربية الوطنية" },
    directorate: { type: String, default: "مديرية التربية لولاية الجزائر غرب" },
    department: { type: String, default: "مصلحة المالية والوسائل" },
    logo: { type: String, default: null },
  },
  theme: { type: String, default: "light" },
  hideCopyright: { type: Boolean, default: false },
  evictionGraceDays: { type: Number, default: 30 },
  aiEnabled: { type: Boolean, default: false },
  aiModel: { type: String, default: "claude-haiku-4-5-20251001" },
  /* ملاحظة أمنية: مفتاح الذكاء الاصطناعي يُخزَّن هنا على الخادم فقط (وليس على متغير بيئة)
     إن رغب المدير في ضبطه من واجهة الإعدادات مباشرة. يُفضَّل ضبطه كمتغير بيئة ANTHROPIC_API_KEY
     على الخادم بدل حفظه في القاعدة، وفي هذه الحالة يُترك هذا الحقل فارغاً. */
  aiApiKey: { type: String, default: "" },
});

const activityLogSchema = new mongoose.Schema({
  at: { type: Date, default: Date.now },
  user: { type: String, default: "—" },
  action: { type: String, default: "" },
  detail: { type: String, default: "" },
});

module.exports = {
  Settings: mongoose.model("Settings", settingsSchema),
  ActivityLog: mongoose.model("ActivityLog", activityLogSchema),
};
