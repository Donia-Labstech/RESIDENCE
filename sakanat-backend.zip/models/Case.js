const mongoose = require("mongoose");

const caseSchema = new mongoose.Schema({
  institutionId: { type: mongoose.Schema.Types.ObjectId, ref: "Institution", required: true },
  beneficiaryName: { type: String, default: "" },
  job: { type: String, default: "" },
  workplace: { type: String, default: "" },
  municipality: { type: String, default: "" },
  apartmentNo: { type: String, default: "" },
  roomCount: { type: String, default: "" },
  housingType: { type: String, default: "" },
  benefitType: { type: String, enum: ["ضرورة الخدمة", "منفعة الخدمة", "خارج القطاع"], default: "ضرورة الخدمة" },
  sector: { type: String, default: "" },
  occupantStatus: { type: String, enum: ["نشط", "متقاعد", "متوفى", "منتقل", "غير محدد"], default: "نشط" },
  vacancyStatus: { type: String, enum: ["مشغول", "شاغر", "مسترجع", "غير_مستلم"], default: "مشغول" },
  actualOccupantName: { type: String, default: "" },
  actualOccupantRelation: { type: String, default: "" },
  unusedByBeneficiary: { type: Boolean, default: false },
  notMovedIn: { type: Boolean, default: false },
  decisionRef: {
    number: { type: String, default: "" },
    date: { type: String, default: "" },
    source: { type: String, default: "" },
  },
  evictionOrder: {
    issued: { type: Boolean, default: false },
    date: { type: String, default: "" },
    executed: { type: Boolean, default: false },
  },
  notes: { type: String, default: "" },
  manualFlags: [{ code: String, sev: String, label: String, detail: String }],
  createdAt: { type: Date, default: Date.now },
}, { toJSON: { virtuals: true } });

module.exports = mongoose.model("Case", caseSchema);
