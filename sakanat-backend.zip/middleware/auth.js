const jwt = require("jsonwebtoken");

const ROLES = {
  admin: { label: "مدير النظام", perms: ["*"] },
  finance: { label: "مصلحة المالية والوسائل", perms: ["view", "edit", "import", "export", "evict", "alerts"] },
  inspector: { label: "مفتش مقاطعة", perms: ["view", "edit", "alerts"] },
  viewer: { label: "مستخدم للعرض فقط", perms: ["view"] },
};

function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "يلزم تسجيل الدخول" });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload; // { id, username, role }
    next();
  } catch (e) {
    return res.status(401).json({ error: "جلسة غير صالحة أو منتهية، يرجى تسجيل الدخول مجدداً" });
  }
}

function requirePerm(perm) {
  return (req, res, next) => {
    const role = ROLES[req.user && req.user.role];
    if (!role) return res.status(403).json({ error: "صلاحية غير معروفة" });
    if (role.perms.includes("*") || role.perms.includes(perm)) return next();
    return res.status(403).json({ error: "لا تملك صلاحية كافية لهذا الإجراء" });
  };
}

module.exports = { requireAuth, requirePerm, ROLES };
