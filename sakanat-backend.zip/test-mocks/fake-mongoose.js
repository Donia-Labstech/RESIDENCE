/* محاكاة خفيفة لـ mongoose لاختبار منطق المسارات (routes) فعلياً دون الحاجة لقاعدة بيانات حقيقية.
   تُغطي فقط الاستدعاءات المستخدمة بالفعل في هذا المشروع. */
const { EventEmitter } = require("events");

let seq = 1;
function makeId() { return "id_" + (seq++).toString(36) + Math.random().toString(36).slice(2, 8); }

function applyDefaults(schemaDef, data) {
  const out = {};
  for (const key of Object.keys(schemaDef)) {
    const def = schemaDef[key];
    if (data[key] !== undefined) { out[key] = data[key]; continue; }
    if (def && typeof def === "object" && !Array.isArray(def) && def.type === undefined && !def.ref) {
      // nested object (e.g. decisionRef: {number:{...}, ...}) -> recurse
      out[key] = applyDefaults(def, data[key] || {});
    } else if (def && def.default !== undefined) {
      out[key] = typeof def.default === "function" ? def.default() : def.default;
    } else if (Array.isArray(def)) {
      out[key] = data[key] || [];
    } else {
      out[key] = data[key];
    }
  }
  // أبقِ أي حقول إضافية مرّرها المستخدم وليست في المخطط (مرونة بسيطة)
  for (const key of Object.keys(data)) if (out[key] === undefined) out[key] = data[key];
  return out;
}

function matchFilter(doc, filter) {
  return Object.keys(filter || {}).every((k) => {
    if (k === "_id") return String(doc._id) === String(filter[k]);
    const fv = filter[k];
    if (fv && fv instanceof RegExp) return fv.test(doc[k]);
    return String(doc[k]) === String(fv);
  });
}

class FakeQuery {
  constructor(results) { this._results = results; this._sortFn = null; this._limit = null; }
  sort(spec) {
    const [[key, dir]] = Object.entries(spec);
    this._sortFn = (a, b) => (a[key] > b[key] ? 1 : a[key] < b[key] ? -1 : 0) * (dir < 0 ? -1 : 1);
    return this;
  }
  limit(n) { this._limit = n; return this; }
  select() { return this; }
  then(resolve, reject) {
    try {
      let arr = this._results.slice();
      if (this._sortFn) arr.sort(this._sortFn);
      if (this._limit != null) arr = arr.slice(0, this._limit);
      resolve(arr);
    } catch (e) { reject(e); }
  }
}

function wrapDoc(store, schemaDef, doc) {
  if (doc.__wrapped) return doc;
  Object.defineProperty(doc, "save", {
    value: async function () {
      const idx = store.findIndex((d) => d._id === doc._id);
      if (idx >= 0) store[idx] = doc;
      return doc;
    }, enumerable: false, configurable: true,
  });
  Object.defineProperty(doc, "deleteOne", {
    value: async function () {
      const idx = store.findIndex((d) => d._id === doc._id);
      if (idx >= 0) store.splice(idx, 1);
    }, enumerable: false, configurable: true,
  });
  Object.defineProperty(doc, "toObject", { value: function () { return JSON.parse(JSON.stringify(doc)); }, enumerable: false, configurable: true });
  Object.defineProperty(doc, "__wrapped", { value: true, enumerable: false, configurable: true });
  return doc;
}

function createModel(name, schemaDef) {
  const store = [];
  const Model = function (data) { return wrapDoc(store, schemaDef, Object.assign({ _id: makeId() }, applyDefaults(schemaDef, data || {}))); };
  Model.find = (filter = {}) => new FakeQuery(store.filter((d) => matchFilter(d, filter)).map((d) => wrapDoc(store, schemaDef, d)));
  Model.findOne = async (filter = {}) => { const d = store.find((x) => matchFilter(x, filter)); return d ? wrapDoc(store, schemaDef, d) : null; };
  Model.findById = async (id) => { const d = store.find((x) => String(x._id) === String(id)); return d ? wrapDoc(store, schemaDef, d) : null; };
  Model.create = async (data) => { const doc = Object.assign({ _id: makeId() }, applyDefaults(schemaDef, data || {})); store.push(doc); return wrapDoc(store, schemaDef, doc); };
  Model.countDocuments = async (filter = {}) => store.filter((d) => matchFilter(d, filter)).length;
  Model.deleteMany = async (filter = {}) => {
    const before = store.length;
    for (let i = store.length - 1; i >= 0; i--) if (matchFilter(store[i], filter)) store.splice(i, 1);
    return { deletedCount: before - store.length };
  };
  Model._store = store;
  return Model;
}

const fakeMongoose = new EventEmitter();
fakeMongoose.Schema = function (def) { this._def = def; };
fakeMongoose.Schema.Types = { ObjectId: "ObjectId" };
fakeMongoose.connect = async () => ({});
fakeMongoose.model = (name, schema) => createModel(name, schema._def);

module.exports = fakeMongoose;
